#!c:\users\16571\desktop\ts_code\python\libtscan\libtscanapi\scripts\python.exe

"""
See :mod:`can.logconvert`.
"""

from can.logconvert import main


if __name__ == "__main__":
    main()
